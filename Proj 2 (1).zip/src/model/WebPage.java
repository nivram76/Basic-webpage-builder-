package model;

import java.util.ArrayList;

public class WebPage implements Comparable<WebPage> {

	private String title;
	private static ArrayList<Element> pagecontent;

	public WebPage(String title) {

		this.title = title;
		pagecontent = new ArrayList<Element>();

	}

	public int compareTo(WebPage toCompare) {

		return title.compareTo(toCompare.title);
	}

	public int addElement(Element element) {

		pagecontent.add(element);

		if (element instanceof TagElement) {

			return ((TagElement) element).getId();

		} else {

			return -1;
		}
	}

	public static void enableId(boolean choice) {

		for (Element e : pagecontent) {

			if (e instanceof TagElement) {

				TagElement.enableId(choice);
			}
		}

	}

	public String getWebPageHTML(int indentation) {
		String toReturn = "<!doctype html>" + "\n<html>\n" + "   <head>\n      <meta charset=\"utf-8\"/> \n" + "      <title>"
				+ this.title + "</title>\n   </head>\n   <body>\n";

		for (Element e : pagecontent) {

			toReturn += e.genHTML(indentation);
		}

		toReturn+="   </body>";
		return toReturn + "\n</html>";

	}

	public String stats() {

		int lists = 0, paragraphs = 0, tables = 0;
		double utilization = 0;

		for (Element e : pagecontent) {
			if (e instanceof ListElement) {

				lists++;
			} else if (e instanceof ParagraphElement) {

				paragraphs++;
			} else if (e instanceof TableElement) {

				tables++;
				utilization += ((TableElement) e).getTableUtilization();
			}
		}

		String toReturn = "List Count:" + lists + "\n" + "Paragraph Count:" + paragraphs + "\n" + "Table Count:"
				+ tables + "\n";

		if (tables != 0) {

			toReturn += "TableElement Utilization: " + (utilization /= tables);
		}
		return toReturn;
	}
	
	public void writeToFile(String filename, int indentation) {
		
		Utilities.writeToFile(filename, getWebPageHTML(indentation));
	}
	
	public Element findElem(int id) {
		
		for (Element e : pagecontent) {
			if(e instanceof TagElement) {
				if (((TagElement)e).getId()==id){
					
					return e;
				}
			}
		}
		
		return null;
	}

}
