package model;

import java.util.*;

public class ListElement extends TagElement {

	ArrayList<Element> list = new ArrayList<Element>();

	public ListElement(boolean ordered, String attributes) {

		super((ordered ? "ol" : "ul"), true, null, attributes);

	}

	public void addItem(Element e) {

		list.add(e);
	}

	public String genHTML(int indentation) {

		String toReturn = "";

		toReturn += Utilities.spaces(indentation) + this.getStartTag() + "\n";

		for (Element e : list) {

			toReturn += Utilities.spaces(3 + indentation) + "<li>\n" + e.genHTML(6 + indentation) + "\n" + Utilities.spaces(3 + indentation)
					+ "</li>\n";
		}
		
		toReturn += Utilities.spaces(indentation);
		return toReturn + this.getEndTag();
	}
}
//FIX INDENTATION