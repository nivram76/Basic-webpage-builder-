package model;

public class TableElement extends TagElement {

	private Element[][] table;

	public TableElement(int rows, int cols, String attributes) {

		super("table", true, null, attributes);

		table = new Element[rows][cols];
	}

	public void addItem(int rowIndex, int colIndex, Element item) {

		table[rowIndex][colIndex] = item;
	}

	public double getTableUtilization() {

		double entries = 0;
		for (int r = 0; r < table.length; r++) {
			for (int c = 0; c < table[0].length; c++) {
				if (table[r][c] != null) {
					entries++;
				}
			}
		}

		return 100 * entries / (table.length * table[0].length);
	}

	public String genHTML(int indentation) {

		String toReturn = "";

		toReturn += Utilities.spaces(indentation);

		toReturn += this.getStartTag() + "\n";

		for (int r = 0; r < table.length; r++) {
			toReturn += Utilities.spaces(3 + indentation) + "<tr>";
			for (int c = 0; c < table[0].length; c++) {

				toReturn += "<td>" + (table[r][c] != null ? table[r][c].genHTML(0) : "") + "</td>";

			}

			toReturn += "</tr>" + "\n";

		}

		return toReturn + Utilities.spaces(indentation) + getEndTag();
	}
}
