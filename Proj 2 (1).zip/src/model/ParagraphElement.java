package model;

import java.util.*;

public class ParagraphElement extends TagElement {

	private ArrayList<Element> body = new ArrayList<Element>();

	public ParagraphElement(String attributes) {

		super("p", true, null, attributes);
	}

	public void addItem(Element item) {

		body.add(item);
	}

	public String genHTML(int indentation) {

		String toReturn = this.getStartTag()+"\n";

		for (Element e : body) {

			toReturn += e.genHTML(indentation) + "\n";
		}

		return toReturn + this.getEndTag();
	}
}
