package model;

/*
 * Class that represents a webpage's HTML tags
 */
public class TagElement implements Element {

	private String tagName;
	private boolean endTag;
	private Element content;
	private String attributes;
	private static int id = 1;
	private int elementid;
	private static boolean enableID = true;

	public TagElement(String tagName, boolean endTag, Element content, String attributes) {

		this.tagName = tagName;
		this.endTag = endTag;
		this.content = content;
		this.attributes = (attributes == null ? "" : attributes);
		elementid = id;
		id++;
	}

	public String genHTML(int indentation) {

		String toReturn = "";

		for (int i = 0; i < indentation; i++) {

			toReturn += " ";
		}

		return toReturn += getStartTag() + (content != null ? content.genHTML(0) : "")
				+ (endTag == true ? getEndTag() : "");
	}

	public static void enableId(boolean choice) {

		enableID = choice;
	}

	public int getId() {

		return id;
	}

	public static void resetIds() {

		id = 1;
	}

	public String getStartTag() {

		String toReturn = "<" + tagName;
		if (enableID) {

			attributes = " id=\"" + tagName + elementid + "\" " + attributes;
		}
		return toReturn + attributes + ">";
	}

	public String getEndTag() {

		return "</" + tagName + ">\n";
	}

	public void setAttributes(String attributes) {

		this.attributes = attributes;
	}
}
