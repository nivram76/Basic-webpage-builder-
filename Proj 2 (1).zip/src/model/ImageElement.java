package model;

public class ImageElement extends TagElement {

	private int width;
	private int height;
	private String imageURL;
	private String alt;

	public ImageElement(String imageURL, int width, int height, String alt, String attributes) {

		super("img", false, null, attributes);
		this.width = width;
		this.height = height;
		this.imageURL = imageURL;
		this.alt = alt;

		String temp = " src=\"" + imageURL + "\""+ " width=\"" + width + "\" " + "height=\"" + height + "\" ";

		if (alt != null) {

			temp += "alt=\"" + alt + "\"";
		}

		setAttributes(temp);
	}

	public String getImageURL() {

		return imageURL;
	}

}
